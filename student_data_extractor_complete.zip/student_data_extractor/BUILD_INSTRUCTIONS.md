# تعليمات بناء تطبيق مستخرج بيانات الطلاب - UNRWA

## نظرة عامة
هذا المشروع عبارة عن تطبيق ويب مستقل (client-side only) لاستخراج بيانات الطلاب من موقع الأونروا (UNRWA). تم تحويله إلى تطبيق Android باستخدام Capacitor.

## المتطلبات

### للبناء على Windows/Mac/Linux:
1. **Java JDK 11 أو أحدث**
   - تحميل من: https://www.oracle.com/java/technologies/downloads/
   - أو استخدام OpenJDK

2. **Android SDK**
   - تحميل Android Studio من: https://developer.android.com/studio
   - أو تحميل Command-line tools من: https://developer.android.com/studio#command-tools

3. **Node.js و pnpm**
   - تحميل Node.js من: https://nodejs.org/
   - تثبيت pnpm: `npm install -g pnpm`

4. **Gradle** (يتم تضمينه مع المشروع)

## خطوات البناء

### الخطوة 1: إعداد متغيرات البيئة

#### على Windows:
```batch
set ANDROID_HOME=C:\Users\YourUsername\AppData\Local\Android\Sdk
set JAVA_HOME=C:\Program Files\Java\jdk-21
set PATH=%ANDROID_HOME%\platform-tools;%ANDROID_HOME%\tools;%JAVA_HOME%\bin;%PATH%
```

#### على Mac/Linux:
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64  # أو مسار Java على نظامك
export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$JAVA_HOME/bin:$PATH
```

### الخطوة 2: تثبيت المكتبات

```bash
cd student_data_extractor
pnpm install
```

### الخطوة 3: بناء التطبيق للويب

```bash
pnpm run build
```

### الخطوة 4: مزامنة مع Capacitor

```bash
npx cap sync android
```

### الخطوة 5: بناء ملف APK

#### الطريقة الأولى - استخدام Gradle مباشرة:

```bash
cd android
./gradlew assembleDebug
```

ملف APK سيكون في:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

#### الطريقة الثانية - استخدام Android Studio:

1. افتح Android Studio
2. اختر "Open an existing Android Studio project"
3. اختر مجلد `android` من المشروع
4. انتظر انتهاء Gradle sync
5. اضغط على "Build" → "Build Bundle(s) / APK(s)" → "Build APK(s)"
6. سيظهر ملف APK في `android/app/build/outputs/apk/debug/`

## تثبيت APK على الهاتف

### الطريقة الأولى - استخدام ADB:

```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### الطريقة الثانية - نقل يدوي:

1. انقل ملف APK إلى الهاتف
2. افتح مدير الملفات على الهاتف
3. اضغط على ملف APK
4. اتبع التعليمات للتثبيت

## ميزات التطبيق

✅ **استخراج بيانات الطلاب من موقع الأونروا**
- إدخال رقم الهوية وسنة الميلاد
- استخراج: الاسم، المدرسة، الصف، الشعبة، النتيجة، رقم التواصل

✅ **معالجة متزامنة**
- تحديد عدد الطلبات المتزامنة (1-500)
- شريط تقدم مباشر

✅ **تخزين محلي**
- استخدام IndexedDB للتخزين على الجهاز
- حفظ تلقائي للتقدم
- استئناف من حيث توقف

✅ **رفع ملفات Excel**
- دعم ملفات .xlsx و .xls
- تحديد أعمدة الهوية وسنة الميلاد
- معالجة ملفات كبيرة على دفعات

✅ **تصدير النتائج**
- تصدير إلى ملفات Excel
- الحفاظ على جميع الأعمدة الأصلية
- إضافة أعمدة البيانات المستخرجة

✅ **واجهة عربية RTL**
- دعم كامل للغة العربية
- تصميم مستجيب (Responsive)
- مؤشر حالة الإنترنت

## استكشاف الأخطاء

### المشكلة: "ANDROID_HOME is not set"
**الحل:** تأكد من تعيين متغير ANDROID_HOME بشكل صحيح

### المشكلة: "Java not found"
**الحل:** تأكد من تثبيت Java JDK وتعيين JAVA_HOME

### المشكلة: "Gradle build failed"
**الحل:** 
1. نظف مجلد البناء: `./gradlew clean`
2. حاول البناء مرة أخرى: `./gradlew assembleDebug`

### المشكلة: "APK installation failed"
**الحل:**
1. تأكد من تفعيل "Unknown sources" على الهاتف
2. جرب إلغاء تثبيت النسخة القديمة أولاً

## الملفات الرئيسية

```
student_data_extractor/
├── client/
│   └── src/
│       ├── lib/
│       │   ├── localDb.ts          # إدارة IndexedDB
│       │   ├── localScraper.ts     # استخراج البيانات
│       │   ├── localExport.ts      # تصدير Excel
│       │   └── localExtraction.ts  # إدارة الاستخراج
│       └── pages/
│           └── Home.tsx            # الواجهة الرئيسية
├── android/                        # مشروع Android
├── capacitor.config.ts             # إعدادات Capacitor
└── package.json                    # المكتبات المطلوبة
```

## المكتبات المستخدمة

- **React 19** - إطار العمل الأساسي
- **TypeScript** - لغة البرمجة
- **TailwindCSS** - تصميم الواجهة
- **Dexie** - إدارة IndexedDB
- **XLSX** - قراءة وكتابة ملفات Excel
- **Cheerio** - تحليل HTML
- **Capacitor** - تحويل الويب إلى تطبيق موبايل
- **shadcn/ui** - مكونات واجهة المستخدم

## ملاحظات مهمة

⚠️ **التطبيق يعمل بدون سيرفر خارجي**
- جميع البيانات تُخزن محلياً على الجهاز
- لا توجد بيانات تُرسل إلى خوادم خارجية
- يعمل بدون اتصال إنترنت (بعد التحميل الأول)

⚠️ **CORS والطلبات**
- يستخدم fetch API مع CORS
- قد تحتاج إلى proxy في بعض الحالات

⚠️ **الأداء**
- الملفات الكبيرة (أكثر من 10,000 سجل) قد تستغرق وقتاً
- استخدم عدد طلبات متزامنة مناسب (5-20 موصى به)

## الدعم والمساعدة

للمزيد من المعلومات:
- Capacitor: https://capacitorjs.com/
- Android Development: https://developer.android.com/
- React: https://react.dev/

---

**تم بناء هذا التطبيق بنجاح! استمتع باستخدامه.**
