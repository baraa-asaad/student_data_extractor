import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Upload, Download, Play, Pause, RotateCcw, Trash2, Wifi, WifiOff } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import {
  addUploadedFile,
  getUploadedFiles,
  deleteUploadedFile,
  addStudentRecords,
  getStudentRecords,
  getStatistics,
  UploadedFile,
  StudentRecord,
} from '@/lib/localDb';
import { startExtraction, pauseExtraction, resumeExtraction, stopExtraction, isExtractionRunning, retryFailedRecords, ExtractionProgress } from '@/lib/localExtraction';
import { downloadExcel } from '@/lib/localExport';

export default function Home() {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<UploadedFile | null>(null);
  const [studentRecords, setStudentRecords] = useState<StudentRecord[]>([]);
  const [extractionProgress, setExtractionProgress] = useState<ExtractionProgress | null>(null);
  const [concurrentRequests, setConcurrentRequests] = useState(5);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [filterStatus, setFilterStatus] = useState<'all' | 'success' | 'failed' | 'not_enrolled' | 'pending'>('all');
  const [statistics, setStatistics] = useState<any>(null);

  // Load uploaded files on component mount
  useEffect(() => {
    loadUploadedFiles();
    window.addEventListener('online', () => setIsOnline(true));
    window.addEventListener('offline', () => setIsOnline(false));
    return () => {
      window.removeEventListener('online', () => setIsOnline(true));
      window.removeEventListener('offline', () => setIsOnline(false));
    };
  }, []);

  // Load student records when selected file changes
  useEffect(() => {
    if (selectedFile) {
      loadStudentRecords(selectedFile.id!.toString());
      loadStatistics(selectedFile.id!.toString());
    }
  }, [selectedFile]);

  const loadUploadedFiles = async () => {
    try {
      const files = await getUploadedFiles();
      setUploadedFiles(files);
      if (files.length > 0 && !selectedFile) {
        setSelectedFile(files[0]);
      }
    } catch (error) {
      console.error('Error loading files:', error);
      toast.error('خطأ في تحميل الملفات');
    }
  };

  const loadStudentRecords = async (fileId: string) => {
    try {
      const records = await getStudentRecords(fileId);
      setStudentRecords(records);
    } catch (error) {
      console.error('Error loading records:', error);
      toast.error('خطأ في تحميل السجلات');
    }
  };

  const loadStatistics = async (fileId: string) => {
    try {
      const stats = await getStatistics(fileId);
      setStatistics(stats);
    } catch (error) {
      console.error('Error loading statistics:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'array' });
          const worksheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);

          // Show dialog for custom name and column selection
          const customName = prompt('أدخل اسماً مخصصاً للملف:');
          if (!customName) return;

          const identityColumnStr = prompt('أدخل رقم عمود رقم الهوية (0-indexed):');
          const birthYearColumnStr = prompt('أدخل رقم عمود سنة الميلاد (0-indexed):');

          if (!identityColumnStr || !birthYearColumnStr) return;

          const identityColumn = parseInt(identityColumnStr);
          const birthYearColumn = parseInt(birthYearColumnStr);

          // Create uploaded file record
          const uploadedFile: UploadedFile = {
            fileName: file.name,
            customName,
            identityColumn,
            birthYearColumn,
            totalRecords: jsonData.length,
            processedRecords: 0,
            successCount: 0,
            failedCount: 0,
            notEnrolledCount: 0,
            uploadedAt: new Date(),
            originalData: jsonData,
          };

          const fileId = await addUploadedFile(uploadedFile);

          // Create student records
          const studentRecordsToAdd: StudentRecord[] = jsonData.map((row: any) => {
            const values = Object.values(row);
            const identityNo = String(values[identityColumn] || '');
            const birthYear = parseInt(String(values[birthYearColumn] || 0));

            return {
              identityNo,
              birthYear,
              status: 'pending',
              attempts: 0,
              sourceFile: JSON.stringify(row),
              sourceFileId: fileId.toString(),
            };
          });

          await addStudentRecords(studentRecordsToAdd);

          toast.success(`تم تحميل الملف بنجاح: ${jsonData.length} سجل`);
          loadUploadedFiles();
        } catch (error) {
          console.error('Error processing file:', error);
          toast.error('خطأ في معالجة الملف');
        }
      };
      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error('Error uploading file:', error);
      toast.error('خطأ في رفع الملف');
    }
  };

  const handleStartExtraction = async () => {
    if (!selectedFile) {
      toast.error('يرجى اختيار ملف أولاً');
      return;
    }

    if (!isOnline) {
      toast.error('يرجى التأكد من الاتصال بالإنترنت');
      return;
    }

    try {
      setExtractionProgress({
        processed: 0,
        total: selectedFile.totalRecords,
        percentage: 0,
        currentStatus: 'running',
        successCount: 0,
        failedCount: 0,
        notEnrolledCount: 0,
      });

      await startExtraction(selectedFile.id!.toString(), concurrentRequests, (progress) => {
        setExtractionProgress(progress);
      });

      loadStudentRecords(selectedFile.id!.toString());
      loadStatistics(selectedFile.id!.toString());
      toast.success('تم الانتهاء من الاستخراج');
    } catch (error) {
      console.error('Error starting extraction:', error);
      toast.error('خطأ في بدء الاستخراج');
    }
  };

  const handlePauseExtraction = () => {
    pauseExtraction();
    setExtractionProgress(prev => prev ? { ...prev, currentStatus: 'paused' } : null);
    toast.info('تم إيقاف الاستخراج مؤقتاً');
  };

  const handleResumeExtraction = () => {
    resumeExtraction();
    setExtractionProgress(prev => prev ? { ...prev, currentStatus: 'running' } : null);
    toast.info('تم استئناف الاستخراج');
  };

  const handleStopExtraction = () => {
    stopExtraction();
    setExtractionProgress(null);
    toast.info('تم إيقاف الاستخراج');
  };

  const handleDeleteFile = async (fileId: number) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الملف؟')) {
      try {
        await deleteUploadedFile(fileId);
        toast.success('تم حذف الملف بنجاح');
        loadUploadedFiles();
        setSelectedFile(null);
      } catch (error) {
        console.error('Error deleting file:', error);
        toast.error('خطأ في حذف الملف');
      }
    }
  };

  const handleDownloadExcel = async () => {
    if (!selectedFile) {
      toast.error('يرجى اختيار ملف أولاً');
      return;
    }

    try {
      await downloadExcel(selectedFile.id!.toString(), selectedFile.customName);
      toast.success('تم تحميل الملف بنجاح');
    } catch (error) {
      console.error('Error downloading Excel:', error);
      toast.error('خطأ في تحميل الملف');
    }
  };

  const handleRetryFailed = async () => {
    if (!selectedFile) {
      toast.error('يرجى اختيار ملف أولاً');
      return;
    }

    try {
      setExtractionProgress({
        processed: 0,
        total: selectedFile.totalRecords,
        percentage: 0,
        currentStatus: 'running',
        successCount: 0,
        failedCount: 0,
        notEnrolledCount: 0,
      });

      await retryFailedRecords(selectedFile.id!.toString(), concurrentRequests, (progress) => {
        setExtractionProgress(progress);
      });

      loadStudentRecords(selectedFile.id!.toString());
      loadStatistics(selectedFile.id!.toString());
      toast.success('تم إعادة محاولة السجلات الفاشلة');
    } catch (error) {
      console.error('Error retrying failed records:', error);
      toast.error('خطأ في إعادة المحاولة');
    }
  };

  const filteredRecords = studentRecords.filter(record => {
    if (filterStatus === 'all') return true;
    return record.status === filterStatus;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8 rtl" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-4xl font-bold text-slate-900">مستخرج بيانات الطلاب - الأونروا</h1>
            <div className="flex items-center gap-2">
              {isOnline ? (
                <div className="flex items-center gap-2 text-green-600">
                  <Wifi className="w-5 h-5" />
                  <span className="text-sm">متصل</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-red-600">
                  <WifiOff className="w-5 h-5" />
                  <span className="text-sm">غير متصل</span>
                </div>
              )}
            </div>
          </div>
          <p className="text-slate-600">تطبيق مستقل لاستخراج بيانات الطلاب من موقع الأونروا بدون سيرفر خارجي</p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Sidebar - File List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>الملفات المرفوعة</CardTitle>
                <CardDescription>إدارة ملفات Excel</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="file-upload" className="cursor-pointer">
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center hover:border-slate-400 transition">
                      <Upload className="w-6 h-6 mx-auto mb-2 text-slate-400" />
                      <span className="text-sm text-slate-600">اضغط لرفع ملف Excel</span>
                    </div>
                  </Label>
                  <input
                    id="file-upload"
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {uploadedFiles.map(file => (
                    <div
                      key={file.id}
                      onClick={() => setSelectedFile(file)}
                      className={`p-3 rounded-lg cursor-pointer transition ${
                        selectedFile?.id === file.id
                          ? 'bg-blue-100 border-2 border-blue-500'
                          : 'bg-slate-100 border-2 border-transparent hover:bg-slate-200'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-semibold text-sm text-slate-900">{file.customName}</p>
                          <p className="text-xs text-slate-500">{file.totalRecords} سجل</p>
                          <p className="text-xs text-slate-500 mt-1">
                            ✓ {file.successCount} | ✗ {file.failedCount} | ○ {file.notEnrolledCount}
                          </p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteFile(file.id!);
                          }}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Content - Main Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Extraction Controls */}
            <Card>
              <CardHeader>
                <CardTitle>إعدادات الاستخراج</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="concurrent">عدد الطلبات المتزامنة (1-500)</Label>
                  <Input
                    id="concurrent"
                    type="number"
                    min="1"
                    max="500"
                    value={concurrentRequests}
                    onChange={(e) => setConcurrentRequests(Math.max(1, Math.min(500, parseInt(e.target.value) || 1)))}
                    className="mt-2"
                  />
                </div>

                {!extractionProgress ? (
                  <Button
                    onClick={handleStartExtraction}
                    disabled={!selectedFile || !isOnline}
                    className="w-full"
                  >
                    <Play className="w-4 h-4 ml-2" />
                    بدء الاستخراج
                  </Button>
                ) : extractionProgress.currentStatus === 'running' ? (
                  <div className="flex gap-2">
                    <Button
                      onClick={handlePauseExtraction}
                      variant="outline"
                      className="flex-1"
                    >
                      <Pause className="w-4 h-4 ml-2" />
                      إيقاف مؤقت
                    </Button>
                    <Button
                      onClick={handleStopExtraction}
                      variant="destructive"
                      className="flex-1"
                    >
                      إيقاف
                    </Button>
                  </div>
                ) : extractionProgress.currentStatus === 'paused' ? (
                  <div className="flex gap-2">
                    <Button
                      onClick={handleResumeExtraction}
                      className="flex-1"
                    >
                      <Play className="w-4 h-4 ml-2" />
                      استئناف
                    </Button>
                    <Button
                      onClick={handleStopExtraction}
                      variant="destructive"
                      className="flex-1"
                    >
                      إيقاف
                    </Button>
                  </div>
                ) : null}
              </CardContent>
            </Card>

            {/* Progress Bar */}
            {extractionProgress && (
              <Card>
                <CardHeader>
                  <CardTitle>تقدم الاستخراج</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">{extractionProgress.processed} / {extractionProgress.total}</span>
                      <span className="text-sm font-medium">{extractionProgress.percentage}%</span>
                    </div>
                    <Progress value={extractionProgress.percentage} className="h-2" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-green-50 p-3 rounded-lg">
                      <p className="text-xs text-slate-600">منتسب</p>
                      <p className="text-2xl font-bold text-green-600">{extractionProgress.successCount}</p>
                    </div>
                    <div className="bg-red-50 p-3 rounded-lg">
                      <p className="text-xs text-slate-600">فشل</p>
                      <p className="text-2xl font-bold text-red-600">{extractionProgress.failedCount}</p>
                    </div>
                    <div className="bg-yellow-50 p-3 rounded-lg">
                      <p className="text-xs text-slate-600">غير منتسب</p>
                      <p className="text-2xl font-bold text-yellow-600">{extractionProgress.notEnrolledCount}</p>
                    </div>
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <p className="text-xs text-slate-600">المتبقي</p>
                      <p className="text-2xl font-bold text-blue-600">{extractionProgress.total - extractionProgress.processed}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Statistics */}
            {statistics && selectedFile && (
              <Card>
                <CardHeader>
                  <CardTitle>ملخص النتائج</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-4 gap-4">
                    <div className="text-center">
                      <p className="text-3xl font-bold text-slate-900">{statistics.total}</p>
                      <p className="text-sm text-slate-600">إجمالي السجلات</p>
                    </div>
                    <div className="text-center">
                      <p className="text-3xl font-bold text-green-600">{statistics.success}</p>
                      <p className="text-sm text-slate-600">منتسب</p>
                    </div>
                    <div className="text-center">
                      <p className="text-3xl font-bold text-red-600">{statistics.failed}</p>
                      <p className="text-sm text-slate-600">فشل</p>
                    </div>
                    <div className="text-center">
                      <p className="text-3xl font-bold text-yellow-600">{statistics.notEnrolled}</p>
                      <p className="text-sm text-slate-600">غير منتسب</p>
                    </div>
                  </div>

                  <div className="flex gap-2 mt-6">
                    <Button
                      onClick={handleDownloadExcel}
                      variant="outline"
                      className="flex-1"
                    >
                      <Download className="w-4 h-4 ml-2" />
                      تحميل Excel
                    </Button>
                    {statistics.failed > 0 && (
                      <Button
                        onClick={handleRetryFailed}
                        variant="outline"
                        className="flex-1"
                      >
                        <RotateCcw className="w-4 h-4 ml-2" />
                        إعادة محاولة
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Data Preview */}
            {selectedFile && (
              <Card>
                <CardHeader>
                  <CardTitle>معاينة البيانات</CardTitle>
                  <CardDescription>عدد السجلات: {filteredRecords.length}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="all" onValueChange={(value) => setFilterStatus(value as any)}>
                    <TabsList className="grid w-full grid-cols-5">
                      <TabsTrigger value="all">الكل</TabsTrigger>
                      <TabsTrigger value="success">منتسب</TabsTrigger>
                      <TabsTrigger value="failed">فشل</TabsTrigger>
                      <TabsTrigger value="not_enrolled">غير منتسب</TabsTrigger>
                      <TabsTrigger value="pending">انتظار</TabsTrigger>
                    </TabsList>

                    <div className="mt-4 overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>رقم الهوية</TableHead>
                            <TableHead>سنة الميلاد</TableHead>
                            <TableHead>الاسم</TableHead>
                            <TableHead>المدرسة</TableHead>
                            <TableHead>الحالة</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredRecords.slice(0, 10).map((record) => (
                            <TableRow key={record.id}>
                              <TableCell className="text-sm">{record.identityNo}</TableCell>
                              <TableCell className="text-sm">{record.birthYear}</TableCell>
                              <TableCell className="text-sm">{record.fullName || '-'}</TableCell>
                              <TableCell className="text-sm">{record.school || '-'}</TableCell>
                              <TableCell>
                                <span className={`px-2 py-1 rounded text-xs font-medium ${
                                  record.status === 'success' ? 'bg-green-100 text-green-800' :
                                  record.status === 'failed' ? 'bg-red-100 text-red-800' :
                                  record.status === 'not_enrolled' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-blue-100 text-blue-800'
                                }`}>
                                  {record.status === 'success' ? 'منتسب' :
                                   record.status === 'failed' ? 'فشل' :
                                   record.status === 'not_enrolled' ? 'غير منتسب' :
                                   'انتظار'}
                                </span>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>

                    {filteredRecords.length > 10 && (
                      <p className="text-sm text-slate-500 mt-4 text-center">
                        عرض 10 من {filteredRecords.length} سجل
                      </p>
                    )}
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
