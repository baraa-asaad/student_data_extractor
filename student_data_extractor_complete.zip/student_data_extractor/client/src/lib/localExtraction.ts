import { StudentRecord, addStudentRecords, getPendingRecords, updateStudentRecord, updateUploadedFile } from './localDb';
import { scrapeStudentWithRetry } from './localScraper';

export interface ExtractionProgress {
  processed: number;
  total: number;
  percentage: number;
  currentStatus: 'idle' | 'running' | 'paused' | 'completed' | 'error';
  successCount: number;
  failedCount: number;
  notEnrolledCount: number;
}

let extractionState: {
  isRunning: boolean;
  isPaused: boolean;
  sourceFileId: string | null;
  abortController: AbortController | null;
} = {
  isRunning: false,
  isPaused: false,
  sourceFileId: null,
  abortController: null,
};

export async function startExtraction(
  sourceFileId: string,
  concurrentRequests: number = 5,
  onProgress?: (progress: ExtractionProgress) => void
): Promise<void> {
  if (extractionState.isRunning) {
    throw new Error('Extraction is already running');
  }

  extractionState.isRunning = true;
  extractionState.isPaused = false;
  extractionState.sourceFileId = sourceFileId;
  extractionState.abortController = new AbortController();

  try {
    const pendingRecords = await getPendingRecords(sourceFileId);
    const total = pendingRecords.length;
    let processed = 0;
    let successCount = 0;
    let failedCount = 0;
    let notEnrolledCount = 0;

    // Process records in batches
    for (let i = 0; i < total; i += concurrentRequests) {
      if (extractionState.abortController.signal.aborted) {
        break;
      }

      // Wait if paused
      while (extractionState.isPaused) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      const batch = pendingRecords.slice(i, i + concurrentRequests);
      const batchPromises = batch.map(async (record) => {
        try {
          const { data, error } = await scrapeStudentWithRetry(record.identityNo, record.birthYear);

          let status: 'success' | 'failed' | 'not_enrolled';
          if (error) {
            status = 'failed';
            failedCount++;
          } else if (data === null) {
            status = 'not_enrolled';
            notEnrolledCount++;
          } else {
            status = 'success';
            successCount++;
            // Update record with scraped data
            await updateStudentRecord(record.id!, {
              fullName: data.fullName,
              school: data.school,
              grade: data.grade,
              section: data.section,
              result: data.result,
              whatsappLink: data.whatsappLink,
              contactNumber: data.contactNumber,
              status,
              lastAttempt: new Date(),
              attempts: record.attempts + 1,
            });
          }

          if (status !== 'success') {
            await updateStudentRecord(record.id!, {
              status,
              lastAttempt: new Date(),
              attempts: record.attempts + 1,
            });
          }

          processed++;
          onProgress?.({
            processed,
            total,
            percentage: Math.round((processed / total) * 100),
            currentStatus: 'running',
            successCount,
            failedCount,
            notEnrolledCount,
          });
        } catch (error) {
          console.error(`Error processing record ${record.identityNo}:`, error);
          failedCount++;
          processed++;
          await updateStudentRecord(record.id!, {
            status: 'failed',
            lastAttempt: new Date(),
            attempts: record.attempts + 1,
          });
          onProgress?.({
            processed,
            total,
            percentage: Math.round((processed / total) * 100),
            currentStatus: 'running',
            successCount,
            failedCount,
            notEnrolledCount,
          });
        }
      });

      await Promise.all(batchPromises);
    }

    // Update file statistics
    await updateUploadedFile(parseInt(sourceFileId), {
      processedRecords: processed,
      successCount,
      failedCount,
      notEnrolledCount,
    });

    extractionState.isRunning = false;
    onProgress?.({
      processed,
      total,
      percentage: 100,
      currentStatus: 'completed',
      successCount,
      failedCount,
      notEnrolledCount,
    });
  } catch (error) {
    extractionState.isRunning = false;
    console.error('Extraction error:', error);
    throw error;
  }
}

export function pauseExtraction(): void {
  extractionState.isPaused = true;
}

export function resumeExtraction(): void {
  extractionState.isPaused = false;
}

export function stopExtraction(): void {
  extractionState.abortController?.abort();
  extractionState.isRunning = false;
  extractionState.isPaused = false;
}

export function isExtractionRunning(): boolean {
  return extractionState.isRunning;
}

export function isExtractionPaused(): boolean {
  return extractionState.isPaused;
}

export async function retryFailedRecords(
  sourceFileId: string,
  concurrentRequests: number = 5,
  onProgress?: (progress: ExtractionProgress) => void
): Promise<void> {
  // Get failed records
  const { getRecordsByStatus } = await import('./localDb');
  const failedRecords = await getRecordsByStatus(sourceFileId, 'failed');

  if (failedRecords.length === 0) {
    onProgress?.({
      processed: 0,
      total: 0,
      percentage: 100,
      currentStatus: 'completed',
      successCount: 0,
      failedCount: 0,
      notEnrolledCount: 0,
    });
    return;
  }

  // Reset failed records to pending
  for (const record of failedRecords) {
    await updateStudentRecord(record.id!, { status: 'pending' });
  }

  // Start extraction again
  await startExtraction(sourceFileId, concurrentRequests, onProgress);
}
