import * as XLSX from 'xlsx';
import { StudentRecord, getStudentRecords, getUploadedFileById } from './localDb';

export async function exportToExcel(sourceFileId: string, customFileName: string): Promise<Blob> {
  const uploadedFile = await getUploadedFileById(parseInt(sourceFileId));
  const studentRecords = await getStudentRecords(sourceFileId);

  if (!uploadedFile) {
    throw new Error('File not found');
  }

  // Prepare the data for export
  const exportData = uploadedFile.originalData.map((originalRow: any, index: number) => {
    const studentRecord = studentRecords.find(r => r.sourceFile === JSON.stringify(originalRow));
    
    return {
      ...originalRow,
      'اسم الطالب كاملا': studentRecord?.fullName || '',
      'المدرسة': studentRecord?.school || '',
      'الصف': studentRecord?.grade || '',
      'الشعبة': studentRecord?.section || '',
      'النتيجة': studentRecord?.result || '',
      'رابط واتساب': studentRecord?.whatsappLink || '',
      'رقم التواصل': studentRecord?.contactNumber || '',
      'الحالة': getStatusArabic(studentRecord?.status || 'pending'),
    };
  });

  // Create a new workbook
  const ws = XLSX.utils.json_to_sheet(exportData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'البيانات');

  // Set column widths
  const colWidths = [
    { wch: 15 }, // Identity
    { wch: 15 }, // Birth Year
    { wch: 25 }, // Full Name
    { wch: 20 }, // School
    { wch: 10 }, // Grade
    { wch: 10 }, // Section
    { wch: 15 }, // Result
    { wch: 25 }, // WhatsApp
    { wch: 15 }, // Contact
    { wch: 15 }, // Status
  ];
  ws['!cols'] = colWidths;

  // Convert to blob
  const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  return new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

export async function downloadExcel(sourceFileId: string, customFileName: string): Promise<void> {
  try {
    const blob = await exportToExcel(sourceFileId, customFileName);
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${customFileName}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error downloading Excel file:', error);
    throw error;
  }
}

export async function downloadAllExcel(sourceFileIds: string[]): Promise<void> {
  try {
    for (const fileId of sourceFileIds) {
      const uploadedFile = await getUploadedFileById(parseInt(fileId));
      if (uploadedFile) {
        await downloadExcel(fileId, uploadedFile.customName);
        // Add a small delay between downloads
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
  } catch (error) {
    console.error('Error downloading Excel files:', error);
    throw error;
  }
}

function getStatusArabic(status: string): string {
  const statusMap: { [key: string]: string } = {
    'success': 'منتسب',
    'failed': 'فشل',
    'not_enrolled': 'غير منتسب',
    'pending': 'في الانتظار',
  };
  return statusMap[status] || status;
}

export async function getExportStats(sourceFileId: string) {
  const studentRecords = await getStudentRecords(sourceFileId);
  
  return {
    total: studentRecords.length,
    success: studentRecords.filter(r => r.status === 'success').length,
    failed: studentRecords.filter(r => r.status === 'failed').length,
    notEnrolled: studentRecords.filter(r => r.status === 'not_enrolled').length,
    pending: studentRecords.filter(r => r.status === 'pending').length,
  };
}
