import * as cheerio from 'cheerio';

export interface ScrapedData {
  fullName: string;
  school: string;
  grade: string;
  section: string;
  result: string;
  whatsappLink: string;
  contactNumber: string;
}

const UNRWA_URL = 'https://emis.unrwa.org/Result/StudentsResult';
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // 1 second

async function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function scrapeStudent(identityNo: string, birthYear: number, attempt: number = 1): Promise<ScrapedData | null> {
  try {
    const formData = new FormData();
    formData.append('IdentityNo', identityNo);
    formData.append('birthYear', birthYear.toString());

    const response = await fetch(UNRWA_URL, {
      method: 'POST',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      body: formData,
      mode: 'cors',
    });

    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    // Extract data from HTML
    const labels = $('label');
    let fullName = '';
    let school = '';
    let grade = '';
    let section = '';
    let result = '';
    let whatsappLink = '';
    let contactNumber = '';

    // Parse labels to find the data
    labels.each((index, element) => {
      const text = $(element).text().trim();
      const value = $(element).next().text().trim();

      if (text.includes('اسم الطالب كاملا')) {
        fullName = value;
      } else if (text.includes('المدرسة')) {
        school = value;
      } else if (text.includes('الصف')) {
        grade = value;
      } else if (text.includes('الشعبة')) {
        section = value;
      } else if (text.includes('النتيجة')) {
        result = value;
      }
    });

    // Look for WhatsApp link and contact number
    const links = $('a');
    links.each((index, element) => {
      const href = $(element).attr('href') || '';
      if (href.includes('wa.me') || href.includes('whatsapp')) {
        whatsappLink = href;
      }
    });

    // Try to find contact number in p1 class
    const p1Elements = $('p1');
    p1Elements.each((index, element) => {
      const text = $(element).text().trim();
      if (/^\d+$/.test(text) && text.length >= 7) {
        contactNumber = text;
      }
    });

    // Check if student is not enrolled (no data found)
    if (!fullName && !school) {
      return null; // Not enrolled
    }

    return {
      fullName,
      school,
      grade,
      section,
      result,
      whatsappLink,
      contactNumber,
    };
  } catch (error) {
    if (attempt < MAX_RETRIES) {
      const waitTime = RETRY_DELAY * Math.pow(2, attempt - 1); // Exponential backoff
      await delay(waitTime);
      return scrapeStudent(identityNo, birthYear, attempt + 1);
    }
    throw error;
  }
}

export async function scrapeStudentWithRetry(identityNo: string, birthYear: number): Promise<{ data: ScrapedData | null; error: string | null }> {
  try {
    const data = await scrapeStudent(identityNo, birthYear);
    return { data, error: null };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return { data: null, error: errorMessage };
  }
}

export async function scrapeMultipleStudents(
  students: Array<{ identityNo: string; birthYear: number }>,
  concurrentRequests: number = 5,
  onProgress?: (current: number, total: number) => void
): Promise<Array<{ identityNo: string; birthYear: number; data: ScrapedData | null; error: string | null }>> {
  const results: Array<{ identityNo: string; birthYear: number; data: ScrapedData | null; error: string | null }> = [];
  let processed = 0;

  // Process students in batches
  for (let i = 0; i < students.length; i += concurrentRequests) {
    const batch = students.slice(i, i + concurrentRequests);
    const batchResults = await Promise.all(
      batch.map(student => scrapeStudentWithRetry(student.identityNo, student.birthYear))
    );

    batch.forEach((student, index) => {
      const result = batchResults[index];
      results.push({
        identityNo: student.identityNo,
        birthYear: student.birthYear,
        data: result.data,
        error: result.error,
      });
      processed++;
      onProgress?.(processed, students.length);
    });
  }

  return results;
}
