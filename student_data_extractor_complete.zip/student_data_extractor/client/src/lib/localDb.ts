import Dexie, { Table } from 'dexie';

export interface StudentRecord {
  id?: number;
  identityNo: string;
  birthYear: number;
  fullName?: string;
  school?: string;
  grade?: string;
  section?: string;
  result?: string;
  whatsappLink?: string;
  contactNumber?: string;
  status: 'pending' | 'success' | 'failed' | 'not_enrolled';
  attempts: number;
  lastAttempt?: Date;
  sourceFile: string;
  sourceFileId: string;
}

export interface UploadedFile {
  id?: number;
  fileName: string;
  customName: string;
  identityColumn: number;
  birthYearColumn: number;
  totalRecords: number;
  processedRecords: number;
  successCount: number;
  failedCount: number;
  notEnrolledCount: number;
  uploadedAt: Date;
  originalData: any[];
}

export interface ExportRecord extends StudentRecord {
  originalData: any;
}

class StudentDataDB extends Dexie {
  students!: Table<StudentRecord>;
  uploadedFiles!: Table<UploadedFile>;
  exportRecords!: Table<ExportRecord>;

  constructor() {
    super('StudentDataExtractorDB');
    this.version(1).stores({
      students: '++id, sourceFileId, status',
      uploadedFiles: '++id, fileName',
      exportRecords: '++id, sourceFileId',
    });
  }
}

export const db = new StudentDataDB();

// Helper functions for database operations

export async function addUploadedFile(file: UploadedFile): Promise<number> {
  return await db.uploadedFiles.add(file);
}

export async function getUploadedFiles(): Promise<UploadedFile[]> {
  return await db.uploadedFiles.toArray();
}

export async function getUploadedFileById(id: number): Promise<UploadedFile | undefined> {
  return await db.uploadedFiles.get(id);
}

export async function updateUploadedFile(id: number, updates: Partial<UploadedFile>): Promise<number> {
  return await db.uploadedFiles.update(id, updates);
}

export async function deleteUploadedFile(id: number): Promise<void> {
  await db.uploadedFiles.delete(id);
  await db.students.where('sourceFileId').equals(id.toString()).delete();
  await db.exportRecords.where('sourceFileId').equals(id.toString()).delete();
}

export async function addStudentRecords(records: StudentRecord[]): Promise<number> {
  return await db.students.bulkAdd(records);
}

export async function getStudentRecords(sourceFileId: string): Promise<StudentRecord[]> {
  return await db.students.where('sourceFileId').equals(sourceFileId).toArray();
}

export async function updateStudentRecord(id: number, updates: Partial<StudentRecord>): Promise<number> {
  return await db.students.update(id, updates);
}

export async function getPendingRecords(sourceFileId: string): Promise<StudentRecord[]> {
  return await db.students
    .where('sourceFileId')
    .equals(sourceFileId)
    .filter(record => record.status === 'pending')
    .toArray();
}

export async function getRecordsByStatus(sourceFileId: string, status: string): Promise<StudentRecord[]> {
  return await db.students
    .where('sourceFileId')
    .equals(sourceFileId)
    .filter(record => record.status === status)
    .toArray();
}

export async function clearDatabase(): Promise<void> {
  await db.students.clear();
  await db.uploadedFiles.clear();
  await db.exportRecords.clear();
}

export async function getStatistics(sourceFileId: string) {
  const records = await getStudentRecords(sourceFileId);
  return {
    total: records.length,
    success: records.filter(r => r.status === 'success').length,
    failed: records.filter(r => r.status === 'failed').length,
    notEnrolled: records.filter(r => r.status === 'not_enrolled').length,
    pending: records.filter(r => r.status === 'pending').length,
  };
}
