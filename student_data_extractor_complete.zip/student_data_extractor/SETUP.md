# إعداد سريع - مستخرج بيانات الطلاب

## 🚀 البدء الفوري

### للويب (3 خطوات):

```bash
# 1. تثبيت المكتبات
pnpm install

# 2. تشغيل خادم التطوير
pnpm run dev

# 3. افتح المتصفح
# http://localhost:3000
```

### لـ Android:

**الخيار 1: استخدام Android Studio (الأسهل)**
1. افتح Android Studio
2. Open → اختر مجلد `android`
3. انتظر Gradle sync
4. Build → Build APK(s)

**الخيار 2: استخدام Gradle**
```bash
cd android
./gradlew assembleDebug
# APK في: app/build/outputs/apk/debug/app-debug.apk
```

## ✅ قائمة التحقق

- [ ] Node.js 18+ مثبت
- [ ] pnpm مثبت
- [ ] Java JDK 11+ مثبت (للـ Android)
- [ ] Android SDK مثبت (للـ Android)

## 📱 تثبيت على الهاتف

```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

أو انقل الملف يدوياً وثبته من الهاتف.

## 🔧 متغيرات البيئة (للـ Android)

### Windows:
```batch
set ANDROID_HOME=C:\Users\YourName\AppData\Local\Android\Sdk
set JAVA_HOME=C:\Program Files\Java\jdk-21
```

### Mac/Linux:
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
```

## 📚 المزيد من المعلومات

- `README_AR.md` - شرح شامل
- `BUILD_INSTRUCTIONS.md` - تعليمات بناء مفصلة

---

**تم! استمتع بالتطبيق** 🎉
