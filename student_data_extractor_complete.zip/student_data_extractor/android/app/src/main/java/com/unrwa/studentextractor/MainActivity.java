package com.unrwa.studentextractor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
